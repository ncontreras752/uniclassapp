﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UniClassManagerApp.models
{
    public partial class ClassInfo
    {
        public string ClssId { get; set; }
        public string ClssName { get; set; }
        public string ClssBuilding { get; set; }
        public int? ClssRoom { get; set; }
        public string ClssDep { get; set; }
        public int? TchrId { get; set; }

        public virtual TeacherInfo Tchr { get; set; }
    }
}

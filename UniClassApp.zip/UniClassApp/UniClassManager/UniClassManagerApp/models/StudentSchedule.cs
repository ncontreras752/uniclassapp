﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UniClassManagerApp.models
{
    public partial class StudentSchedule
    {
        public int? StdntId { get; set; }
        public string ClassId { get; set; }

        public virtual ClassInfo Class { get; set; }
        public virtual StudentInfo Stdnt { get; set; }
    }
}

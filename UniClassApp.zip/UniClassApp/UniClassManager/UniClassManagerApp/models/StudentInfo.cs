﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UniClassManagerApp.models
{
    public partial class StudentInfo
    {
        public int StdntId { get; set; }
        public string StdntFrstName { get; set; }
        public string StdntLastName { get; set; }
        public string StdntUsername { get; set; }
        public string StdntEmail { get; set; }
        public long StdntNum { get; set; }
        public string Password { get; set; }
    }
}

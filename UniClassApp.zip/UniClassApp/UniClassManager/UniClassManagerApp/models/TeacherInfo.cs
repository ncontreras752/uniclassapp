﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UniClassManagerApp.models
{
    public partial class TeacherInfo
    {
        public TeacherInfo()
        {
            ClassInfos = new HashSet<ClassInfo>();
        }

        public int TchrId { get; set; }
        public string TchrFrstName { get; set; }
        public string TchrLastName { get; set; }
        public string TchrEmail { get; set; }
        public long TchrNum { get; set; }

        public virtual ICollection<ClassInfo> ClassInfos { get; set; }
    }
}

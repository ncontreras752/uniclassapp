﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace UniClassManagerApp.models
{
    public partial class uniClassesDBContext : DbContext
    {
        public uniClassesDBContext()
        {
        }

        public uniClassesDBContext(DbContextOptions<uniClassesDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ClassInfo> ClassInfos { get; set; }
        public virtual DbSet<StudentInfo> StudentInfos { get; set; }
        public virtual DbSet<StudentSchedule> StudentSchedules { get; set; }
        public virtual DbSet<TeacherInfo> TeacherInfos { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=DESKTOP-J7LHH54;database=uniClassesDB; integrated security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<ClassInfo>(entity =>
            {
                entity.HasKey(e => e.ClssId)
                    .HasName("PK__classInf__EBAA54DE0DF79378");

                entity.ToTable("classInfo");

                entity.Property(e => e.ClssId)
                    .HasMaxLength(20)
                    .HasColumnName("clssId");

                entity.Property(e => e.ClssBuilding)
                    .HasMaxLength(20)
                    .HasColumnName("clssBuilding");

                entity.Property(e => e.ClssDep)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("clssDep");

                entity.Property(e => e.ClssName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("clssName");

                entity.Property(e => e.ClssRoom).HasColumnName("clssRoom");

                entity.Property(e => e.TchrId).HasColumnName("tchrId");

                entity.HasOne(d => d.Tchr)
                    .WithMany(p => p.ClassInfos)
                    .HasForeignKey(d => d.TchrId)
                    .HasConstraintName("FK__classInfo__tchrI__5E8A0973");
            });

            modelBuilder.Entity<StudentInfo>(entity =>
            {
                entity.HasKey(e => e.StdntId)
                    .HasName("PK__studentI__139071CACD5A5588");

                entity.ToTable("studentInfo");

                entity.HasIndex(e => e.StdntUsername, "UQ__studentI__115235891464469E")
                    .IsUnique();

                entity.HasIndex(e => e.StdntEmail, "UQ__studentI__D071E3AF8B48BAFA")
                    .IsUnique();

                entity.HasIndex(e => e.StdntNum, "UQ__studentI__EA3283B29A027B75")
                    .IsUnique();

                entity.Property(e => e.StdntId)
                    .ValueGeneratedNever()
                    .HasColumnName("stdntId");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("password");

                entity.Property(e => e.StdntEmail)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("stdntEmail");

                entity.Property(e => e.StdntFrstName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("stdntFrstName");

                entity.Property(e => e.StdntLastName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("stdntLastName");

                entity.Property(e => e.StdntNum).HasColumnName("stdntNum");

                entity.Property(e => e.StdntUsername)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("stdntUsername");
            });

            modelBuilder.Entity<StudentSchedule>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("studentSchedule");

                entity.HasIndex(e => e.StdntId, "UQ__studentS__139071CB8D975EC0")
                    .IsUnique();

                entity.HasIndex(e => e.ClassId, "UQ__studentS__7577347F225C9DE8")
                    .IsUnique();

                entity.Property(e => e.ClassId)
                    .HasMaxLength(20)
                    .HasColumnName("classId");

                entity.Property(e => e.StdntId).HasColumnName("stdntId");

                entity.HasOne(d => d.Class)
                    .WithOne()
                    .HasForeignKey<StudentSchedule>(d => d.ClassId)
                    .HasConstraintName("FK__studentSc__class__634EBE90");

                entity.HasOne(d => d.Stdnt)
                    .WithOne()
                    .HasForeignKey<StudentSchedule>(d => d.StdntId)
                    .HasConstraintName("FK__studentSc__stdnt__625A9A57");
            });

            modelBuilder.Entity<TeacherInfo>(entity =>
            {
                entity.HasKey(e => e.TchrId)
                    .HasName("PK__teacherI__8EED5E36F3758F38");

                entity.ToTable("teacherInfo");

                entity.HasIndex(e => e.TchrEmail, "UQ__teacherI__30EF51152F25D4DF")
                    .IsUnique();

                entity.HasIndex(e => e.TchrNum, "UQ__teacherI__FE29A85AA167C706")
                    .IsUnique();

                entity.Property(e => e.TchrId)
                    .ValueGeneratedNever()
                    .HasColumnName("tchrId");

                entity.Property(e => e.TchrEmail)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("tchrEmail");

                entity.Property(e => e.TchrFrstName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("tchrFrstName");

                entity.Property(e => e.TchrLastName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("tchrLastName");

                entity.Property(e => e.TchrNum).HasColumnName("tchrNum");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}

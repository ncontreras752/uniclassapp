using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using UniClassManagerApp.models;

namespace UniClassManagerApp
{
    class AppAuth
    {
        public int stdntId;

        //prompts user for the username and password
        public Boolean loginDisplay() {
            Console.Clear();
            Console.WriteLine("Please Enter Your Username:");
            var username = Console.ReadLine();
            Console.WriteLine("Please Enter Your Password:");
            var password = ReadPassword();
            
            //calls userlogin to verify the username and password in the database
            return userLogin(username, password);
        }

        //I did not make this one
         public static string ReadPassword()
        {
            string password = "";
            ConsoleKeyInfo info = Console.ReadKey(true);
            while (info.Key != ConsoleKey.Enter)
            {
                if (info.Key != ConsoleKey.Backspace)
                {
                    Console.Write("*");
                    password += info.KeyChar;
                }
                else if (info.Key == ConsoleKey.Backspace)
                {
                    if (!string.IsNullOrEmpty(password))
                    {
                        // remove one character from the list of password characters
                        password = password.Substring(0, password.Length - 1);
                        // get the location of the cursor
                        int pos = Console.CursorLeft;
                        // move the cursor to the left by one character
                        Console.SetCursorPosition(pos - 1, Console.CursorTop);
                        // replace it with space
                        Console.Write(" ");
                        // move the cursor to the left by one character again
                        Console.SetCursorPosition(pos - 1, Console.CursorTop);
                    }
                }
                info = Console.ReadKey(true);
            }

            // add a new line because user pressed enter at the end of their password
            Console.WriteLine();
            return password;
        }

        //authenticates the user
        public Boolean userLogin(string username, string password) {
            var uniClassManagerDBObj = new uniClassesDBContext();

            //gets the result of the query
            var loginOutPut = new SqlParameter(){
                ParameterName = "result",
                DbType = System.Data.DbType.String,Size=20,
                Direction = System.Data.ParameterDirection.Output
            };

            //gets the student id from the database
            var stdntIdOutPut = new SqlParameter(){
                ParameterName = "stdntId",
                DbType = System.Data.DbType.Int32,
                Direction = System.Data.ParameterDirection.Output
            };

            try
            {
                var authentication = uniClassManagerDBObj.Database
                    .ExecuteSqlRaw($"proc_login {username}, {password}, @result output, @stdntId out", loginOutPut, stdntIdOutPut);
            }
            catch (SqlException)
            {
                Console.WriteLine("Please Enter A Valid Username Or Password");
                return false;
            }

            if((string)loginOutPut.Value == "Login Successful") {
                stdntId = (int)stdntIdOutPut.Value;
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(loginOutPut.Value);
                Console.ResetColor();
                return true; 
            } else {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(loginOutPut.Value);
                Console.ResetColor();
                return false;
            }
        }

        //limits the amount of attempts a user has to login
        public Boolean attempts() {
            for(int i=3; i >= 0; i--) {
                //checks if if user has been authenticated
                if(loginDisplay()) {
                    i = 0;
                    return true;
                //if not authenticated shows user how many attempts they have left 
                } else {
                    Console.WriteLine($"{i} Attempts Left Press 'Enter' To Try Again:");
                    Console.ReadLine();
                    Console.Clear();
                }
            }
            
            //if user goes over alloted attempts they will get kicked out of the system
            Console.WriteLine("Too Many Failed Attempts, Goodbye");
            return false;
        }

        //logs the user out
        public Boolean userLogout() {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Successfully Logged Out");
            Console.ResetColor();
            return false;
        }
    }
}
﻿using System;

namespace UniClassManagerApp
{
    class Program
    {
        static int validNumber() {
            int selection = 0;

            try
            {
                return selection = Convert.ToInt32(Console.ReadLine());
            }
            catch(FormatException)
            {
                Console.WriteLine("Please Enter A Valid Number");
                return selection;
            }
        }
        static void menuReturn() {
            Console.WriteLine("\nPress 'Enter' To Return To Main Menu");
            Console.ReadLine();
            Console.Clear();
        }

        static void Main(string[] args)
        {
            AppAuth login = new AppAuth();
            StdntAccount myAccount = new StdntAccount();
            CourseCatalogue classes = new CourseCatalogue();
            StdntSchedule mySchedule = new StdntSchedule();
            bool authenticated = false;
            bool exit = false;
            int selection = 0;

            do
            {
                Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~ Welcome To University Class Management ~~~~~~~~~~~~~~~~~~~~~~~");
                Console.WriteLine("Please pick one of the following options by entering the corresponding number:");
                Console.WriteLine("1. Login");
                Console.WriteLine("2. Create Account");
                Console.WriteLine("3. Exit Class Manager");
                Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

                selection = validNumber();

                switch (selection)
                {
                    case 1:
                        authenticated = login.attempts();

                        exit = true;
                        break;

                    case 2:
                        Console.Clear();
                        Console.WriteLine("Please Enter Your First Name:");
                        myAccount.stdntFirstName = Console.ReadLine();
                        Console.WriteLine("Please Enter Your Last Name:");
                        myAccount.stdntLastName = Console.ReadLine();
                        Console.WriteLine("Please Enter Your Phone Number:");
                        try{
                            myAccount.stdntNum = Convert.ToInt64(Console.ReadLine());
                        }
                        catch(FormatException)
                        {
                            Console.WriteLine("Please Enter A Valid Number");
                            myAccount.stdntNum = Convert.ToInt64(Console.ReadLine());
                        }
                        Console.WriteLine("Please Enter Your Password:");
                        myAccount.stdntPassword = Console.ReadLine();

                        myAccount.createAccount();
                        menuReturn();
                        break;

                    case 3:
                        exit = true;
                        break;

                    default:
                        break;
                }

            } while(!exit);

            while(authenticated) {
                Console.WriteLine($"Welcome, This Is Your Current Schedule:");
                mySchedule.viewSchedule(login.stdntId);
                Console.WriteLine("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                Console.WriteLine("Please pick one of the following options by entering the corresponding number:");
                Console.WriteLine("1. Add Class");
                Console.WriteLine("2. Remove Class");
                Console.WriteLine("3. View Course Catalogue");
                Console.WriteLine("4. Update Account Info");
                Console.WriteLine("5. Logout and Exit");
                Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

                selection = validNumber();
                Console.Clear();

                switch (selection)
                {
                    case 1:
                        Console.Clear();
                        mySchedule.viewSchedule(login.stdntId);
                        Console.WriteLine("\nPlease Enter The Class ID:");
                        mySchedule.addClass(login.stdntId, Console.ReadLine());
                        menuReturn();
                        break;

                    case 2: 
                        Console.Clear();
                        mySchedule.viewSchedule(login.stdntId);
                        Console.WriteLine("\nPlease Enter The Class ID:");
                        mySchedule.removeClass(login.stdntId, Console.ReadLine());
                        menuReturn();
                        break;

                    case 3:
                        classes.catalogueDisplay();
                        Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        Console.WriteLine("1. Filter By Department");
                        Console.WriteLine("2. View Class In Detail");
                        Console.WriteLine("3. To Return To Main Menu:");
                        Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

                        selection = validNumber();

                        switch (selection)
                        {
                            case 1:
                                Console.WriteLine("Please Enter The Department:");
                                classes.depSearch(Console.ReadLine());
                                menuReturn();
                                break;

                            case 2:
                                Console.WriteLine("Please Enter The Class ID Exactly As Shown In the Catalogue:");
                                classes.classIdSearch(Console.ReadLine());
                                menuReturn();
                                break;

                            case 3:
                                break;
                            
                            default:
                                Console.WriteLine("Please Enter A Valid Selection");
                                break;
                        }

                        Console.Clear();
                        break;

                    case 4:
                        Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                        Console.WriteLine("1. Enter The Desired Updates When Prompted");
                        Console.WriteLine("2. Change Password");
                        Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

                        selection = validNumber();

                        switch (selection)
                        {
                            case 1:
                                myAccount.update(login.stdntId);
                                menuReturn();
                                break;

                            case 2:
                                if(login.attempts()) {
                                    Console.WriteLine("Please Enter New Password:");
                                    myAccount.update(login.stdntId, Console.ReadLine());
                                    menuReturn();
                                    break;
                                }
                                break;

                            default:
                                break;
                        }

                        break;

                    case 5:
                        authenticated = login.userLogout();
                        break;

                    default:

                        break;
                }
            }
            Console.ReadLine();
            Console.Clear();
        }
    }
}
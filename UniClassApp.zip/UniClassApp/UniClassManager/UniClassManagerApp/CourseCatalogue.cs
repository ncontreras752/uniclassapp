using System;
using System.Linq;
using System.Collections.Generic;
using UniClassManagerApp.models;

namespace UniClassManagerApp
{
    class CourseCatalogue
    {
        public void catalogueDisplay() {
            var uniClassManagerDBObj = new uniClassesDBContext();
            
            var classes = from a in uniClassManagerDBObj.ClassInfos
                select a;

            Console.Clear();
            
            foreach (var item in classes)
            {
                Console.WriteLine($"Class ID: {item.ClssId}\t\tClass Name: {item.ClssName}\t\tTeacher ID: {item.TchrId}");
                Console.WriteLine($"Deparment: {item.ClssDep}\t\tBuilding: {item.ClssBuilding}\t\tRoom: {item.ClssRoom}\n");
            }
        }

        public void depSearch(string classDepartment) {
            var uniClassManagerDBObj = new uniClassesDBContext();

            var searchResult = from a in uniClassManagerDBObj.ClassInfos
                               where a.ClssDep == classDepartment
                               select new {a.ClssId, a.ClssName, a.ClssBuilding, a.ClssRoom, a.TchrId};
            
            foreach (var item in searchResult)
            {
                Console.WriteLine($"{item.ClssId} {item.ClssName} ");
            }
        }

        public void classIdSearch(string classId) {
            var uniClassManagerDBObj = new uniClassesDBContext();

            var searchResult = from a in uniClassManagerDBObj.ClassInfos
                               join b in uniClassManagerDBObj.TeacherInfos 
                               on a.TchrId equals b.TchrId where a.ClssId == classId
                               select new {a.ClssId, a.ClssName, a.ClssDep, a.ClssBuilding, a.ClssRoom, b.TchrFrstName, b.TchrLastName, b.TchrEmail};

            foreach (var item in searchResult)
            {
                Console.WriteLine($"\nClass Name: {item.ClssName}\t\tDeparment: {item.ClssDep}");
                Console.WriteLine($"Building: {item.ClssBuilding}\t\tRoom: {item.ClssRoom}");
                Console.WriteLine($"Teacher: {item.TchrFrstName} {item.TchrLastName}\t\tEmail: {item.TchrEmail}");
            }
        } 
    }
}
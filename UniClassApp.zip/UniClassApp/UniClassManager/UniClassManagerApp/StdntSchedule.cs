using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using UniClassManagerApp.models;

namespace UniClassManagerApp
{
    class StdntSchedule
    {
        public void viewSchedule(int studentId) {
            var uniClassManagerDBObj = new uniClassesDBContext();
            //joins student schedule and class info tables for display
            var schedule = from a in uniClassManagerDBObj.StudentSchedules
                           join b in uniClassManagerDBObj.ClassInfos 
                           on a.ClassId equals b.ClssId where a.StdntId == studentId
                           select new {a.StdntId, b.ClssId, b.ClssName, b.ClssBuilding, b.ClssRoom, b.TchrId};
            
            Console.WriteLine("Class ID\tClass Name\t\tBuilding\tRoom Number\tTeacher ID");
            //displays the necessary items for each class in the schedule
            foreach (var item in schedule)
            {
                Console.WriteLine($"{item.ClssId}\t{item.ClssName}\t\t{item.ClssBuilding}\t\t{item.ClssRoom}\t\t{item.TchrId}");
            }
        }
        
        public void addClass(int studentId, string classId) {
            var uniClassManagerDBObj = new uniClassesDBContext();
        
            try
            {
                var addClass = uniClassManagerDBObj.Database
                    .ExecuteSqlRaw($"proc_addClass {studentId}, '{classId}'");
            }
            catch (SqlException)
            {
                Console.WriteLine("Please Enter A Valid Class ID");
            }
        }

        public void removeClass(int studentId, string classId) {
            var uniClassManagerDBObj = new uniClassesDBContext();

            try
            {
                var addClass = uniClassManagerDBObj.Database
                    .ExecuteSqlRaw($"proc_removeClass {studentId}, '{classId}'");
            }
            catch (SqlException)
            {
                Console.WriteLine("Please Enter A Valid Class ID");
            }
        }
    }
}
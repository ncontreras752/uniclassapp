using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using UniClassManagerApp.models;

namespace UniClassManagerApp
{
    class StdntAccount
    {
        AppAuth login = new AppAuth();
        private string password;
        public long stdntNum { get; set; }
        public string stdntFirstName { get; set; }
        public string stdntLastName { get; set; }
        public string stdntPassword { set{password = value;} }

        //creates the username for the user
        private string createUsername() {
            string stdntUsername;
            var uniClassManagerDBObj = new uniClassesDBContext();

            //concatenates the first letter of the first name and the last 2 letters of the last name
            stdntUsername = $"{stdntFirstName.Substring(0, 1)}{stdntLastName.Substring(0, 2)}";

            //checks for duplicates in the database
            var username = from a in uniClassManagerDBObj.StudentInfos
                           where a.StdntUsername.Contains(stdntUsername)
                           select new { a.StdntUsername };
            
            //if duplicates are found adds number to username
            if(username.Count() > 0) {
                stdntUsername = $"{stdntUsername}{username.Count()}";
            }

            //returns the username in lowercase
            return stdntUsername.ToLower();
        }
        
        //creates the account in the database
        public void createAccount() {
            var uniClassManagerDBObj = new uniClassesDBContext();
            //calls the createUsername function to create the username
            string username = (createUsername());
            //creates email by concatenating the username with the school's email
            string email =  $"{username}@myuni.edu";

            try
            {
                //uses stored procedure in order to add the account to the database
                var accountCreation = uniClassManagerDBObj.Database
                    .ExecuteSqlRaw($"proc_addAccount {stdntFirstName}, {stdntLastName}, {username}, '{email}', {stdntNum}, {password}");

                //displays the username and email to the user
                Console.WriteLine("\nYour Username And Email:");
                Console.WriteLine($"Username: {username}\nEmail: {email}");
            }
            catch (SqlException)
            {
                Console.WriteLine("Account Creation Failed One Or More Fields Invalid");
            }
        }

        //handles updating user information
        public void update(int stdntId) {
            var uniClassManagerDBObj = new uniClassesDBContext();
            string input = null;
            long numInput;

            Console.WriteLine("If You Do Not Wish To Update The Field Press 'Enter'\n");
            Console.WriteLine("Please Enter Your New First Name:");
            input = Console.ReadLine();
            try
            {
                //checks to see if input is null if it is it does not update the first name
                if(input != "") {
                    var updateName = uniClassManagerDBObj.Database
                        .ExecuteSqlRaw($"proc_updateFrstName {stdntId}, {input}");
            }
            }
            catch (SqlException)
            {
                Console.WriteLine("Unable To Update First Name");
            }

            Console.WriteLine("Please Enter Your New Last Name:");
            input = Console.ReadLine();
            try
            {
                //checks to see if input is null if it is it does not update the last name
                if(input != "") {
                    var updateName = uniClassManagerDBObj.Database
                        .ExecuteSqlRaw($"proc_updateLastName {stdntId}, {input}");
                }
            }
            catch (SqlException)
            {
                Console.WriteLine("Unable To Update Last Name");
            }
            
            //updates the phone number if a number is entered
            Console.WriteLine("Please Enter Your New Phone Number:");
            try
            {
                numInput = Convert.ToInt64(Console.ReadLine());
                var updateName = uniClassManagerDBObj.Database
                    .ExecuteSqlRaw($"proc_updateLastName {stdntId}, {input}");
            }
            catch (FormatException){}
            catch (SqlException) {
                Console.WriteLine("Unable To Update Phone Number");
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Updates Performed Successfully");
            Console.ResetColor();
        }

        //updates the users password
        public void update(int stdntId, string password) {
            var uniClassManagerDBObj = new uniClassesDBContext();

            //uses stored procedure to update password
            try
            {
                var updatePassword = uniClassManagerDBObj.Database
                    .ExecuteSqlRaw($"proc_updatePassword {stdntId}, {password}");
            }
            catch (SqlException)
            {
                Console.WriteLine("Unable To Update Password");
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Password Updated Successfully");
            Console.ResetColor();
        }
    }
}